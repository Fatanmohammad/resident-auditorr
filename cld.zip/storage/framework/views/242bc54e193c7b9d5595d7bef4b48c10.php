<?php $__env->startSection('title', 'Buat WP Offsite Baru'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div class="page-header-title">
        <h1>Buat WP Offsite Baru</h1>
        <p>Kertas Kerja Pemantauan Harian (SOP 02)</p>
    </div>
    <a href="<?php echo e(route('offsite-review.index')); ?>" class="btn btn-outline btn-sm">
        <i class="bi bi-arrow-left"></i> Kembali
    </a>
</div>

<div class="card" style="max-width:600px;">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('offsite-review.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label class="form-label">Unit <span style="color:#dc2626;">*</span></label>
                <select name="unit_id" class="form-select" required>
                    <option value="">— Pilih Unit —</option>
                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($u->id); ?>" <?php echo e(old('unit_id') == $u->id ? 'selected' : ''); ?>>
                        <?php echo e($u->unit_name); ?> (<?php echo e($u->unit_type); ?>)
                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['unit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label class="form-label">RA Pelaksana</label>
                <select name="ra_id" class="form-select">
                    <option value="">— Pilih RA —</option>
                    <?php $__currentLoopData = $ras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ra->id); ?>" <?php echo e(old('ra_id') == $ra->id ? 'selected' : ''); ?>>
                        <?php echo e($ra->ra_name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="grid grid-cols-2" style="gap:1rem;">
                <div class="form-group">
                    <label class="form-label">Tahun <span style="color:#dc2626;">*</span></label>
                    <input type="number" name="tahun" class="form-input"
                        value="<?php echo e(old('tahun', date('Y'))); ?>" min="2020" max="2099" required>
                    <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label class="form-label">Bulan <span style="color:#dc2626;">*</span></label>
                    <select name="bulan" class="form-select" required>
                        <?php $__currentLoopData = range(1,12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($b); ?>" <?php echo e(old('bulan', date('n')) == $b ? 'selected' : ''); ?>>
                            <?php echo e(\Carbon\Carbon::create(null, $b)->isoFormat('MMMM')); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Reviewer</label>
                <input type="text" name="reviewer" class="form-input"
                    value="<?php echo e(old('reviewer')); ?>" placeholder="Nama reviewer">
            </div>

            <div class="form-group" style="display:flex;align-items:center;gap:0.75rem;">
                <input type="checkbox" name="validasi_unit" id="validasi_unit" value="1"
                    <?php echo e(old('validasi_unit') ? 'checked' : ''); ?>

                    style="width:16px;height:16px;cursor:pointer;">
                <label for="validasi_unit" class="form-label" style="margin:0;cursor:pointer;">
                    Unit sudah tervalidasi
                </label>
            </div>

            <div style="display:flex;gap:0.75rem;margin-top:1.5rem;">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-plus-lg"></i> Buat WP
                </button>
                <a href="<?php echo e(route('offsite-review.index')); ?>" class="btn btn-outline">Batal</a>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\resident-auditor\resources\views/offsite-review/create.blade.php ENDPATH**/ ?>