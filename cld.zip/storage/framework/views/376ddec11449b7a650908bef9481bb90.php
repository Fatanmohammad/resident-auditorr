<?php $__env->startSection('title', 'Offsite Review — Daftar WP'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div class="page-header-title">
        <h1><i class="bi bi-clipboard2-data" style="color:var(--bs-blue);"></i> Offsite Review</h1>
        <p>Daftar Kertas Kerja Pemantauan Harian (SOP 02)</p>
    </div>
    <a href="<?php echo e(route('offsite-review.create')); ?>" class="btn btn-primary btn-sm">
        <i class="bi bi-plus-lg"></i> Buat WP Baru
    </a>
</div>

<div class="card">
    <div class="table-wrapper">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Kode WP</th>
                    <th>Unit</th>
                    <th>RA Pelaksana</th>
                    <th>Periode</th>
                    <th style="text-align:center;">Status</th>
                    <th style="text-align:center;">Validasi Unit</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $wps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><span style="font-family:monospace;font-weight:600;color:var(--bs-blue);"><?php echo e($wp->kode_wp); ?></span></td>
                    <td>
                        <div style="font-weight:500;"><?php echo e($wp->unit->unit_name ?? '-'); ?></div>
                        <div style="font-size:0.72rem;color:var(--text-muted);"><?php echo e($wp->unit->unit_type ?? ''); ?></div>
                    </td>
                    <td><?php echo e($wp->ra->ra_name ?? '-'); ?></td>
                    <td><?php echo e($wp->periode_data); ?></td>
                    <td style="text-align:center;">
                        <span class="badge <?php echo e(match($wp->status_wp) {
                            'Approved'  => 'badge-success',
                            'Final'     => 'badge-info',
                            'In Review' => 'badge-warning',
                            default     => 'badge-gray'
                        }); ?>"><?php echo e($wp->status_wp); ?></span>
                    </td>
                    <td style="text-align:center;">
                        <?php if($wp->validasi_unit): ?>
                            <span style="color:#16a34a;font-size:1rem;">✅</span>
                        <?php else: ?>
                            <span style="color:#d97706;font-size:1rem;">⚠️</span>
                        <?php endif; ?>
                    </td>
                    <td style="text-align:right;">
                        <a href="<?php echo e(route('offsite-review.dashboard', $wp)); ?>" class="btn btn-outline btn-sm">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">
                        <div class="empty-state">
                            <i class="bi bi-clipboard2-x"></i>
                            <p>Belum ada WP Offsite. <a href="<?php echo e(route('offsite-review.create')); ?>">Buat yang pertama.</a></p>
                        </div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($wps->hasPages()): ?>
    <div style="padding:1rem 1.25rem;border-top:1px solid var(--border-color);">
        <?php echo e($wps->links()); ?>

    </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\resident-auditor\resources\views/offsite-review/index.blade.php ENDPATH**/ ?>