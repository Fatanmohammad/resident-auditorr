<?php $__env->startSection('content'); ?>
<div>
    <div style="margin-bottom: 1rem;">
        <a href="<?php echo e(route('admin-offsite.index', ['tahun' => $tahun, 'bulan' => $bulan])); ?>" class="btn btn-outline" style="padding: 0.4rem 0.75rem; font-size: 0.8rem; background: #fff;">
            <i class="bi bi-arrow-left"></i> Kembali ke Daftar Cabang
        </a>
    </div>

    <div class="page-header">
        <div class="page-header-title">
            <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.25rem;">
                <span class="badge badge-gray" style="font-family: monospace;"><?php echo e($cabang->cabang_code); ?></span>
                <span class="badge badge-info">Periode: <?php echo e(\Carbon\Carbon::create($tahun, $bulan)->isoFormat('MMMM Y')); ?></span>
            </div>
            <h1 style="margin: 0; font-size: 1.25rem; font-weight: 700; color: var(--bs-blue-dark);"><?php echo e($cabang->cabang_name); ?></h1>
            <p style="color: var(--text-muted); font-size: 0.85rem; margin-top: 0.25rem;">Daftar Unit Operasional dan Status Pelaksanaan Offsite Review</p>
        </div>
        <div class="page-header-actions">
            <form method="GET" style="display: flex; align-items: flex-end; gap: 0.5rem;">
                <div style="display: flex; flex-direction: column; gap: 0.25rem;">
                    <label style="font-size: 0.7rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase;">Status Review</label>
                    <select name="status" class="form-select" style="padding: 0.4rem 2rem 0.4rem 0.75rem; font-size: 0.8rem; width: auto; height: 34px;">
                        <option value="">Semua Status Review</option>
                        <option value="perlu_review" <?php if(request('status') === 'perlu_review'): echo 'selected'; endif; ?>>Perlu Review</option>
                        <option value="tidak_perlu" <?php if(request('status') === 'tidak_perlu'): echo 'selected'; endif; ?>>Tidak Perlu Review</option>
                        <option value="selesai" <?php if(request('status') === 'selesai'): echo 'selected'; endif; ?>>Selesai Review</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-outline" style="height: 34px; padding: 0 1rem; font-size: 0.8rem; background: #fff;">
                    <i class="bi bi-funnel"></i> Filter
                </button>
            </form>
        </div>
    </div>

    <?php
        $totalUnit = count($unitData);
        $perluReviewCount = collect($unitData)->filter(fn($i) => in_array($i['status_review'], ['Perlu Review', 'Dalam Review']))->count();
        $selesaiCount = collect($unitData)->filter(fn($i) => $i['status_review'] === 'Selesai Review')->count();
        $highRiskCount = collect($unitData)->filter(fn($i) => $i['risiko_tertinggi'] === 'High')->count();
    ?>

    <div class="grid grid-cols-4" style="margin-bottom: 1.5rem;">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="bi bi-diagram-3"></i>
            </div>
            <div class="stat-info">
                <div class="stat-label">TOTAL UNIT</div>
                <div class="stat-value"><?php echo e($totalUnit); ?></div>
                <div class="stat-sub">Terdaftar di Cabang</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon yellow">
                <i class="bi bi-exclamation-circle"></i>
            </div>
            <div class="stat-info">
                <div class="stat-label">PERLU REVIEW</div>
                <div class="stat-value"><?php echo e($perluReviewCount); ?></div>
                <div class="stat-sub">Menunggu Tindak Lanjut</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="bi bi-check-circle"></i>
            </div>
            <div class="stat-info">
                <div class="stat-label">SELESAI REVIEW</div>
                <div class="stat-value"><?php echo e($selesaiCount); ?></div>
                <div class="stat-sub">Review Telah Rampung</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon red">
                <i class="bi bi-shield-exclamation"></i>
            </div>
            <div class="stat-info">
                <div class="stat-label">RISIKO TINGGI</div>
                <div class="stat-value"><?php echo e($highRiskCount); ?></div>
                <div class="stat-sub">Area Risiko High</div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="card-title">Rincian Unit Operasional</div>
            <div style="font-size: 0.8rem; color: var(--text-muted); font-weight: 500;">
                Menampilkan <?php echo e($totalUnit); ?> unit
            </div>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 10%;">KODE UNIT</th>
                            <th style="width: 20%;">NAMA UNIT</th>
                            <th style="width: 10%;">JENIS UNIT</th>
                            <th style="width: 12%; text-align: center;">AREA RISIKO</th>
                            <th style="width: 13%; text-align: center;">RISIKO TERTINGGI</th>
                            <th style="width: 15%; text-align: center;">STATUS REVIEW</th>
                            <th style="width: 12%;">UPDATE TERAKHIR</th>
                            <th style="width: 8%; text-align: right;">AKSI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $unitData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <span class="badge badge-gray" style="font-family: monospace;"><?php echo e($item['unit']->unit_code); ?></span>
                                </td>
                                <td style="font-weight: 600; color: var(--bs-blue-dark);"><?php echo e($item['unit']->unit_name); ?></td>
                                <td style="color: var(--text-muted);"><?php echo e($item['unit']->unit_type); ?></td>
                                <td style="text-align: center;">
                                    <span class="badge badge-gray"><?php echo e($item['total_area_risiko']); ?> Area</span>
                                </td>
                                <td style="text-align: center;">
                                    <?php if($item['risiko_tertinggi'] === 'High'): ?>
                                        <span class="badge badge-danger">High</span>
                                    <?php elseif(in_array($item['risiko_tertinggi'], ['Moderate', 'Moderate to High'])): ?>
                                        <span class="badge badge-warning"><?php echo e($item['risiko_tertinggi']); ?></span>
                                    <?php elseif(in_array($item['risiko_tertinggi'], ['Low', 'Low to Moderate'])): ?>
                                        <span class="badge badge-success"><?php echo e($item['risiko_tertinggi']); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-gray"><?php echo e($item['risiko_tertinggi']); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align: center;">
                                    <?php if(in_array($item['status_review'], ['Perlu Review', 'Dalam Review'])): ?>
                                        <span class="badge badge-warning"><?php echo e($item['status_review']); ?></span>
                                    <?php elseif($item['status_review'] === 'Selesai Review'): ?>
                                        <span class="badge badge-success"><?php echo e($item['status_review']); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-gray"><?php echo e($item['status_review']); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td style="color: var(--text-muted); font-size: 0.75rem;">
                                    <?php echo e($item['terakhir_update'] ? \Carbon\Carbon::parse($item['terakhir_update'])->isoFormat('D MMM Y, HH:mm') : '-'); ?>

                                </td>
                                <td style="text-align: right;">
                                    <a href="<?php echo e(route('admin-offsite.unit-detail', $item['unit']->id)); ?>?tahun=<?php echo e($tahun); ?>&bulan=<?php echo e($bulan); ?>" 
                                       class="btn btn-outline" style="padding: 0.35rem 0.75rem; font-size: 0.75rem;">
                                        Detail
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8">
                                    <div class="empty-state">
                                        <i class="bi bi-inbox"></i>
                                        <p>Tidak ada unit dengan kriteria filter yang dipilih.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\resident-auditor\resources\views/admin-offsite/cabang-detail.blade.php ENDPATH**/ ?>