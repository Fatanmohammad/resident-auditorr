<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <a href="<?php echo e(route('admin-offsite.unit-detail', $wp->unit_id)); ?>?tahun=<?php echo e($wp->periode_mulai->format('Y')); ?>&bulan=<?php echo e($wp->periode_mulai->format('n')); ?>" 
       class="btn btn-sm btn-secondary mb-3">← Kembali ke Detail Unit</a>

    <h2 class="mb-1">KKA <?php echo e($areaLabel); ?></h2>
    <p class="text-muted"><?php echo e($wp->kode_wp); ?> — <?php echo e($wp->nama_unit); ?></p>

    <div class="card">
        <div class="table-responsive">
            <table class="table table-sm table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Deskripsi/Narasi</th>
                        <th>Nominal</th>
                        <th>Risk Awal</th>
                        <th>Dampak</th>
                        <th>Kemungkinan</th>
                        <th>Skor Risiko</th>
                        <th>Kategori Final</th>
                        <th>Status Review</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($i + 1); ?></td>
                        <td><?php echo e($row->tanggal_data->format('d/m/Y')); ?></td>
                        <td><?php echo e(Str::limit($row->deskripsi_narasi, 50)); ?></td>
                        <td><?php echo e(number_format($row->nominal, 0, ',', '.')); ?></td>
                        <td>
                            <span class="badge bg-<?php echo e($row->risk_awal === 'High' ? 'danger' : ($row->risk_awal === 'Moderate' ? 'warning' : 'secondary')); ?>">
                                <?php echo e($row->risk_awal ?? '-'); ?>

                            </span>
                        </td>
                        <td><?php echo e($row->dampak ?? '-'); ?></td>
                        <td><?php echo e($row->kemungkinan ?? '-'); ?></td>
                        <td><?php echo e($row->skor_risiko ?? '-'); ?></td>
                        <td><?php echo e($row->kategori_risiko_final ?? '-'); ?></td>
                        <td><?php echo e($row->status_review ?? 'Belum Review'); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin-offsite.kka-show', [$wp->id, $area, $row->kka_id])); ?>" 
                               class="btn btn-sm btn-primary">Detail</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="11" class="text-center text-muted py-4">Belum ada data KKA untuk area ini.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\resident-auditor\resources\views/admin-offsite/kka-index.blade.php ENDPATH**/ ?>