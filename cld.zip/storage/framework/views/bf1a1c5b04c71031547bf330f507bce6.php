<?php $__env->startSection('title', 'Master Unit'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="page-header-title">
        <h1>Master Unit</h1>
        <p>Daftar seluruh unit kerja bank (Audit Universe)</p>
    </div>
<?php if(in_array(auth()->user()->role, ['kabag_ra','kadiv_skai','admin'])): ?>
    <a href="<?php echo e(route('units.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Tambah Unit</a>
    <?php endif; ?>
</div>

<div class="card">
    <div class="table-wrapper">
        <table class="data-table">
<thead>
<tr>
                    <?php $isRa = auth()->user()->role === 'ra'; ?>
                    <th>Kode</th><th>Nama Unit</th><th>Tipe</th><th>Kantor Induk</th><th>Base RA Unit</th>
                    <th>Status Risiko</th><th>Status</th><th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $scoring = $unit->riskScorings->first();
                    $riskCls = match($scoring?->final_category) {
                        'High'=>'badge-danger','Moderate to High'=>'badge-warning',
                        'Moderate'=>'badge-info','Low to Moderate'=>'badge-purple',default=>'badge-gray'
                    };
                ?>
                <tr>
                    <td style="font-size:0.78rem;color:var(--text-muted);"><?php echo e($unit->unit_code); ?></td>
                    <td><strong><?php echo e($unit->unit_name); ?></strong></td>
                    <td><span class="badge badge-info"><?php echo e($unit->unit_type); ?></span></td>
                    <td style="font-size:0.82rem;"><?php echo e($unit->parent_office ?? '-'); ?></td>
                    <td style="font-size:0.82rem;"><?php echo e($unit->base_ra_unit ?? '<span style="color:#dc2626;">Belum diset</span>'); ?></td>
<td>
                        <?php if($scoring): ?>
                            <span class="badge <?php echo e($riskCls); ?>"><?php echo e($scoring->final_category); ?></span>
                        <?php else: ?>
                            <span class="badge badge-gray">Belum dinilai</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge <?php echo e($unit->is_active ? 'badge-success' : 'badge-gray'); ?>">
                            <?php echo e($unit->is_active ? 'Aktif' : 'Nonaktif'); ?>

                        </span>
                    </td>
<td style="display:flex;gap:0.4rem;">
                        <?php if(auth()->user()->role !== 'ra'): ?>
                        <a href="<?php echo e(route('units.show', $unit)); ?>" class="btn btn-outline btn-sm" title="Detail"><i class="bi bi-eye"></i></a>
                        <?php endif; ?>
<?php if(in_array(auth()->user()->role, ['kabag_ra','kadiv_skai','admin'])): ?>
                        <a href="<?php echo e(route('units.edit', $unit)); ?>" class="btn btn-outline btn-sm" title="Edit"><i class="bi bi-pencil"></i></a>
                        <?php endif; ?>
                        <?php if(in_array(auth()->user()->role, ['kabag_ra','ra','admin'])): ?>
                        <a href="<?php echo e(route('raw-metrics.create', $unit)); ?>" class="btn btn-outline btn-sm" title="Input Data Mentah"><i class="bi bi-input-cursor-text"></i></a>
                        <?php endif; ?>
                    </td>
                </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr><td colspan="8"><div class="empty-state"><i class="bi bi-building-x"></i><p>Belum ada data unit. Tambah unit atau jalankan seeder.</p></div></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\resident-auditor\resources\views/units/index.blade.php ENDPATH**/ ?>