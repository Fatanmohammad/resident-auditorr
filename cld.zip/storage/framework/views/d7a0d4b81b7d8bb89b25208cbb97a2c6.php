<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <a href="<?php echo e(route('dashboard')); ?>">
            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo Bank Sulteng">
        </a>
    </div>

    <div class="sidebar-nav">
        <?php
            $role = auth()->user()->role;
// Role yang boleh mengelola master data (Admin/Operasional)
            $canManage = in_array($role, ['kabag_ra', 'kadiv_skai', 'admin']);
// Role yang bisa input raw metrics & override (admin = akses sama seperti kabag_ra)
            $canInput  = in_array($role, ['kabag_ra', 'ra', 'admin']);
// Audit Plan & submenunya (termasuk Data Unit) tampil untuk semua akun terkait termasuk RA
$canView   = in_array($role, ['ra', 'kabag_ra', 'kadiv_skai', 'pimsie', 'admin']);
            // RA hanya melihat submenu Data Unit di dalam Audit Plan (sesuai kebutuhan)
            $isRa = $role === 'ra';
        ?>

        <a href="<?php echo e(route('dashboard')); ?>" class="nav-item <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
            <i class="bi bi-speedometer2 nav-icon"></i> Dashboard
        </a>

        
        <?php if($canView): ?>
<div class="nav-group open <?php echo e(request()->routeIs('units.*', 'raw-metrics.*', 'risk-scoring.index', 'assignment-ra.*', 'coverage.*', 'scheduling.*', 'final-audit-plan.*') ? 'open' : ''); ?>">
            <div class="nav-group-toggle">
                <i class="bi bi-clipboard2-pulse nav-icon"></i> Audit Plan
                <i class="bi bi-chevron-down nav-arrow"></i>
            </div>
            <div class="nav-group-children">


                <a href="<?php echo e(route('units.index')); ?>" class="nav-item <?php echo e((request()->routeIs('units.*', 'raw-metrics.*') && request('from') !== 'risk-scoring') ? 'active' : ''); ?>">
                    <i class="bi bi-building nav-icon"></i> Data Unit
                </a>

<?php if(!$isRa): ?>
                
<div class="nav-subgroup <?php echo e(request()->routeIs('risk-scoring.index') || request('from') === 'risk-scoring' ? 'open' : ''); ?>">
                    <div class="nav-subgroup-toggle">
                        <i class="bi bi-shield-exclamation nav-icon"></i> Penilaian Risiko
                        <i class="bi bi-chevron-down nav-subgroup-arrow"></i>
                    </div>
<div class="nav-subgroup-children">
                        <a href="<?php echo e(route('risk-scoring.index')); ?>" class="nav-item <?php echo e(request()->routeIs('risk-scoring.index') || request('from') === 'risk-scoring' ? 'active' : ''); ?>">
                            <i class="bi bi-bar-chart nav-icon"></i> Hasil Skor & Kategori
                        </a>
                    </div>
                </div>

                
                <a href="<?php echo e(route('assignment-ra.index')); ?>" class="nav-item <?php echo e(request()->routeIs('assignment-ra.*') ? 'active' : ''); ?>">
                    <i class="bi bi-person-check nav-icon"></i> Assignment RA
                </a>
                <?php endif; ?>


                <?php if($canManage): ?>
                <a href="<?php echo e(route('coverage.index')); ?>" class="nav-item <?php echo e(request()->routeIs('coverage.*') ? 'active' : ''); ?>">
                    <i class="bi bi-grid-3x3-gap nav-icon"></i> Coverage Offsite
                </a>
                <?php endif; ?>

                
                <?php if(!$isRa): ?>
                <div class="nav-subgroup <?php echo e(request()->routeIs('scheduling.*') ? 'open' : ''); ?>">
                    <div class="nav-subgroup-toggle">
                        <i class="bi bi-calendar3 nav-icon"></i> Jadwal Onsite
                        <i class="bi bi-chevron-down nav-subgroup-arrow"></i>
                    </div>
                    <div class="nav-subgroup-children">
                        <a href="<?php echo e(route('scheduling.index')); ?>" class="nav-item <?php echo e(request()->routeIs('scheduling.index', 'scheduling.unit') ? 'active' : ''); ?>">
                            <i class="bi bi-calendar-week nav-icon"></i> Frekuensi & Kalender
                        </a>
                        <a href="<?php echo e(route('scheduling.capacity')); ?>" class="nav-item <?php echo e(request()->routeIs('scheduling.capacity') ? 'active' : ''); ?>">
                            <i class="bi bi-speedometer nav-icon"></i> Kapasitas RA
                        </a>
                    </div>
                </div>


                <a href="<?php echo e(route('final-audit-plan.index')); ?>" class="nav-item <?php echo e(request()->routeIs('final-audit-plan.index', 'final-audit-plan.show') ? 'active' : ''); ?>">
                    <i class="bi bi-clipboard2-check nav-icon"></i> Final Audit Plan
                </a>
                <?php endif; ?>

                
                <?php if($canManage): ?>
                <a href="<?php echo e(route('final-audit-plan.change-log')); ?>" class="nav-item <?php echo e(request()->routeIs('final-audit-plan.change-log') ? 'active' : ''); ?>">
                    <i class="bi bi-clock-history nav-icon"></i> Change Log
                </a>
                <?php endif; ?>

            </div>
        </div>
        <?php endif; ?>

        
        <?php if(!$isRa || $canInput): ?>
        <a href="<?php echo e(route('offsite-review.index')); ?>" class="nav-item <?php echo e(request()->routeIs('offsite-review.*') ? 'active' : ''); ?>">
            <i class="bi bi-clipboard2-data nav-icon"></i> Offsite Review
        </a>
        <?php endif; ?>


        <?php if(in_array($role, ['pimsie', 'kadiv_skai', 'kabag_ra', 'admin'])): ?>
        <a href="<?php echo e(route('audit-plan.index')); ?>" class="nav-item <?php echo e(request()->routeIs('audit-plan.*') ? 'active' : ''); ?>">
            <i class="bi bi-kanban nav-icon"></i> Audit Plan (Workflow)
        </a>
        <?php endif; ?>

        
        <?php if($role === 'admin'): ?>
        <a href="<?php echo e(route('admin-offsite.index')); ?>" class="nav-item <?php echo e(request()->routeIs('admin-offsite.*') ? 'active' : ''); ?>">
            <i class="bi bi-house-check nav-icon"></i> Admin Offsite
        </a>
        <?php endif; ?>

        
        <?php if($role === 'admin'): ?>
        <a href="<?php echo e(route('master-setup.index')); ?>" class="nav-item <?php echo e(request()->routeIs('master-setup.*') ? 'active' : ''); ?>">
            <i class="bi bi-gear nav-icon"></i> Pengaturan Modul
        </a>
        <?php endif; ?>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    // Toggle level-2 (nav-group)
    document.querySelectorAll('.nav-group-toggle').forEach(function(toggle) {
        toggle.addEventListener('click', function() {
            toggle.parentElement.classList.toggle('open');
        });
    });
    // Toggle level-3 (nav-subgroup)
    document.querySelectorAll('.nav-subgroup-toggle').forEach(function(toggle) {
        toggle.addEventListener('click', function() {
            toggle.parentElement.classList.toggle('open');
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH E:\laragon\www\resident-auditor\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>