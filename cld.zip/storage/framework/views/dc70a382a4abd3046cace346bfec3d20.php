<?php $__env->startSection('title', 'Audit Plan — SOP 01'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div class="page-header-title">
        <h1>Audit Plan</h1>
        <p>SOP 01 — Perencanaan Audit Resident Auditor <?php echo e(now()->year); ?></p>
    </div>
</div>




<div style="margin-bottom: 2rem;">
    <div style="display:flex; align-items:flex-start; gap:0; position:relative;">

        <?php
            $steps = [
[
                    'num'   => 1,
                    'label' => 'Master Unit',
                    'desc'  => 'Data universe unit pengawasan',
                    'icon'  => 'bi-diagram-3',
                    'done'  => $unitCount > 0,
                    'roles' => ['kadiv_skai','kabag_ra','pimsie','admin'],
                    'links' => [
                        ['label'=>'Lihat Master Unit','url'=>route('units.index'),'icon'=>'bi-eye'],
                        ['label'=>'Tambah Unit','url'=>route('units.create'),'icon'=>'bi-plus-lg','roles'=>['kadiv_skai','kabag_ra','admin']],
                    ],
                ],
                [
                    'num'   => 2,
                    'label' => 'Input Risiko',
                    'desc'  => 'Raw metrics & risk scoring per unit',
                    'icon'  => 'bi-graph-up-arrow',
                    'done'  => $rawMetricCount > 0,
                    'roles' => ['kadiv_skai','kabag_ra','ra','admin'],
                    'links' => [
                        ['label'=>'Input Raw Metrics','url'=>route('units.index').'?action=raw-metrics','icon'=>'bi-pencil-square','roles'=>['kabag_ra','ra','admin']],
                    ],
                ],
                [
                    'num'   => 3,
                    'label' => 'Penugasan RA',
                    'desc'  => 'Coverage & assignment RA ke unit',
                    'icon'  => 'bi-person-check',
                    'done'  => $coverageCount > 0,
                    'roles' => ['kadiv_skai','kabag_ra','admin'],
                    'links' => [
                        ['label'=>'Kelola Coverage','url'=>route('units.index').'?action=coverage','icon'=>'bi-people','roles'=>['kadiv_skai','kabag_ra','admin']],
                    ],
                ],
                [
                    'num'   => 4,
                    'label' => 'Jadwal Kunjungan',
                    'desc'  => 'Frekuensi onsite & kapasitas RA',
                    'icon'  => 'bi-calendar-range',
                    'done'  => $scheduleCount > 0,
                    'roles' => ['kadiv_skai','kabag_ra','pimsie','admin'],
                    'links' => [
                        ['label'=>'Lihat Jadwal','url'=>route('scheduling.index'),'icon'=>'bi-calendar3'],
                        ['label'=>'Kapasitas RA','url'=>route('scheduling.capacity'),'icon'=>'bi-person-check','roles'=>['kadiv_skai','kabag_ra','admin']],
                        ['label'=>'Generate Semua','url'=>'#','icon'=>'bi-lightning-charge','roles'=>['kadiv_skai','kabag_ra','admin'],'post'=>route('scheduling.generate-all')],
                    ],
                ],
                [
                    'num'   => 5,
                    'label' => 'Final Audit Plan',
                    'desc'  => 'Output akhir & change log',
                    'icon'  => 'bi-clipboard2-check',
                    'done'  => $finalPlanCount > 0,
                    'roles' => ['kadiv_skai','kabag_ra','pimsie','ra','admin'],
                    'links' => [
                        ['label'=>'Lihat Final Plan','url'=>route('final-audit-plan.index'),'icon'=>'bi-eye'],
                        ['label'=>'Change Log','url'=>route('final-audit-plan.change-log'),'icon'=>'bi-clock-history'],
                        ['label'=>'Generate Final Plan','url'=>'#','icon'=>'bi-lightning-charge','roles'=>['kadiv_skai','kabag_ra','admin'],'post'=>route('final-audit-plan.generate-all')],
                    ],
                ],
            ];
            $role = auth()->user()->role;
        ?>

        <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(in_array($role, $step['roles'])): ?>
        <div style="flex:1; position:relative; <?php echo e($i < count($steps)-1 ? '' : ''); ?>">
            
            <?php if($i < count($steps)-1): ?>
            <div style="position:absolute; top:20px; left:calc(50% + 20px); right:calc(-50% + 20px); height:2px; background:<?php echo e($step['done'] ? 'var(--bs-blue)' : 'var(--border-color)'); ?>; z-index:0;"></div>
            <?php endif; ?>

            <div style="display:flex; flex-direction:column; align-items:center; position:relative; z-index:1;">
                
                <div style="width:40px; height:40px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:700; font-size:0.85rem; flex-shrink:0;
                    background:<?php echo e($step['done'] ? 'var(--bs-blue)' : 'var(--bg-main)'); ?>;
                    color:<?php echo e($step['done'] ? '#fff' : 'var(--text-muted)'); ?>;
                    border:2px solid <?php echo e($step['done'] ? 'var(--bs-blue)' : 'var(--border-color)'); ?>;">
                    <?php if($step['done']): ?>
                    <i class="bi bi-check-lg"></i>
                    <?php else: ?>
                    <?php echo e($step['num']); ?>

                    <?php endif; ?>
                </div>
                
                <div style="margin-top:0.5rem; text-align:center;">
                    <div style="font-size:0.78rem; font-weight:600; color:<?php echo e($step['done'] ? 'var(--bs-blue-dark)' : 'var(--text-muted)'); ?>;"><?php echo e($step['label']); ?></div>
                    <div style="font-size:0.68rem; color:var(--text-muted); margin-top:0.1rem;"><?php echo e($step['desc']); ?></div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>




<div style="display:flex; flex-direction:column; gap:1rem;">
    <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(in_array($role, $step['roles'])): ?>
    <div class="card" style="border-left:3px solid <?php echo e($step['done'] ? 'var(--bs-blue)' : 'var(--border-color)'); ?>;">
        <div class="card-header" style="cursor:pointer;" onclick="toggleStep('step<?php echo e($step['num']); ?>')">
            <div style="display:flex; align-items:center; gap:0.75rem;">
                <div style="width:36px; height:36px; border-radius:50%; display:flex; align-items:center; justify-content:center;
                    background:<?php echo e($step['done'] ? 'var(--bs-blue)' : 'var(--bg-main)'); ?>;
                    border:2px solid <?php echo e($step['done'] ? 'var(--bs-blue)' : 'var(--border-color)'); ?>;">
                    <i class="bi <?php echo e($step['done'] ? 'bi-check-lg' : $step['icon']); ?>" style="font-size:0.85rem; color:<?php echo e($step['done'] ? '#fff' : 'var(--text-muted)'); ?>;"></i>
                </div>
                <div>
                    <div style="font-size:0.9rem; font-weight:600; color:var(--bs-blue-dark);">
                        Step <?php echo e($step['num']); ?> — <?php echo e($step['label']); ?>

                    </div>
                    <div style="font-size:0.75rem; color:var(--text-muted);"><?php echo e($step['desc']); ?></div>
                </div>
            </div>
            <div style="display:flex; align-items:center; gap:0.75rem;">
                <span class="badge <?php echo e($step['done'] ? 'badge-success' : 'badge-gray'); ?>">
                    <?php echo e($step['done'] ? 'Selesai' : 'Belum'); ?>

                </span>
                <i class="bi bi-chevron-down" id="chevron-step<?php echo e($step['num']); ?>" style="color:var(--text-muted); font-size:0.75rem; transition:transform 0.2s;"></i>
            </div>
        </div>
        <div id="step<?php echo e($step['num']); ?>" style="display:none; padding:0 1.25rem 1.25rem;">
            <div style="display:flex; flex-wrap:wrap; gap:0.5rem; padding-top:0.75rem; border-top:1px solid var(--border-color);">
                <?php $__currentLoopData = $step['links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!isset($link['roles']) || in_array($role, $link['roles'])): ?>
                    <?php if(isset($link['post'])): ?>
                    <form action="<?php echo e($link['post']); ?>" method="POST" style="margin:0;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-outline btn-sm">
                            <i class="bi <?php echo e($link['icon']); ?>"></i> <?php echo e($link['label']); ?>

                        </button>
                    </form>
                    <?php else: ?>
                    <a href="<?php echo e($link['url']); ?>" class="btn btn-outline btn-sm">
                        <i class="bi <?php echo e($link['icon']); ?>"></i> <?php echo e($link['label']); ?>

                    </a>
                    <?php endif; ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>




<div style="margin-top:2rem;">
    <div style="font-size:0.72rem; font-weight:600; color:var(--text-muted); text-transform:uppercase; letter-spacing:0.05em; margin-bottom:0.75rem;">
        Approval Audit Plan
    </div>
    <div class="card">
        <div class="card-header">
            <div class="card-title">Daftar Audit Plan</div>
            <?php if($role === 'pimsie'): ?>
            <a href="<?php echo e(route('audit-plan.create')); ?>" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-lg"></i> Buat Audit Plan
            </a>
            <?php endif; ?>
        </div>
        <div class="table-wrapper">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>RA</th>
                        <th>Periode</th>
                        <th>Jadwal</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $auditPlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><strong><?php echo e($plan->raUser?->name ?? '-'); ?></strong></td>
                        <td><?php echo e($plan->tahun_periode); ?></td>
                        <td style="font-size:0.78rem;">
                            <?php echo e(\Carbon\Carbon::parse($plan->jadwal_mulai)->format('d M Y')); ?><br>
                            <span style="color:var(--text-muted);">s/d <?php echo e(\Carbon\Carbon::parse($plan->jadwal_selesai)->format('d M Y')); ?></span>
                        </td>
                        <td>
                            <?php
                                $cls = match($plan->status_approval) {
                                    'approved'               => 'badge-success',
                                    'rejected'               => 'badge-danger',
                                    'waiting_kabag_approval' => 'badge-warning',
                                    'waiting_kadiv_approval' => 'badge-purple',
                                    default                  => 'badge-gray',
                                };
                                $lbl = match($plan->status_approval) {
                                    'approved'               => 'Approved',
                                    'rejected'               => 'Ditolak',
                                    'waiting_kabag_approval' => 'Menunggu Kabag',
                                    'waiting_kadiv_approval' => 'Menunggu Kadiv',
                                    default                  => $plan->status_approval,
                                };
                            ?>
                            <span class="badge <?php echo e($cls); ?>"><?php echo e($lbl); ?></span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('audit-plan.show', $plan->id)); ?>" class="btn btn-outline btn-sm">
                                <i class="bi bi-eye"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5"><div class="empty-state"><i class="bi bi-calendar-x"></i><p>Belum ada Audit Plan.</p></div></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function toggleStep(id) {
    const el = document.getElementById(id);
    const chevron = document.getElementById('chevron-' + id);
    const isOpen = el.style.display !== 'none';
    el.style.display = isOpen ? 'none' : 'block';
    chevron.style.transform = isOpen ? '' : 'rotate(180deg)';
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\resident-auditor\resources\views/audit-plan/index.blade.php ENDPATH**/ ?>